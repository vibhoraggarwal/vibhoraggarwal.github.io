from rosbags.highlevel import AnyReader
from rosbags.typesys import get_typestore, Stores
import matplotlib.pyplot as plt
import csv
from pathlib import Path

def read_bag(bag_path):
    """Read odometry messages from ROS2 bag."""
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    x_coords = []
    y_coords = []

    with AnyReader([Path(bag_path)], default_typestore=typestore) as reader:
        # Find connections for /odom_sim topic
        odom_connections = [c for c in reader.connections if c.topic == '/odom_sim']

        if not odom_connections:
            print("Warning: No /odom_sim topic found in bag file")
            print("Available topics:")
            for c in reader.connections:
                print(f"  - {c.topic}")
            return [], []

        print(f"Reading odometry data from /odom_sim...")

        for connection, timestamp, rawdata in reader.messages(connections=odom_connections):
            msg = reader.deserialize(rawdata, connection.msgtype)

            x_coords.append(msg.pose.pose.position.x)
            y_coords.append(msg.pose.pose.position.y)

    return x_coords, y_coords

def save_to_csv(x_coords, y_coords, filename='../_data/trajectory_data.csv'):
    """Save trajectory data to CSV file."""
    # Create _data directory if it doesn't exist
    output_path = Path(filename)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(filename, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['x', 'y'])  # Header
        for x, y in zip(x_coords, y_coords):
            writer.writerow([x, y])
    print(f"Trajectory data saved to '{filename}'")

def plot_trajectory(x_coords, y_coords):
    """Plot the x-y trajectory."""
    plt.figure(figsize=(12, 10))

    # Plot trajectory
    plt.plot(x_coords, y_coords, 'b-', linewidth=1.5, alpha=0.7, label='Trajectory')

    # Mark start and end points
    plt.plot(x_coords[0], y_coords[0], 'go', markersize=10, label='Start')
    plt.plot(x_coords[-1], y_coords[-1], 'ro', markersize=10, label='End')

    plt.xlabel('X Position (m)', fontsize=12)
    plt.ylabel('Y Position (m)', fontsize=12)
    plt.title('Odometry Trajectory (X-Y Plot)', fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.axis('equal')
    plt.legend()
    plt.tight_layout()

    # Save the plot
    output_file = Path('../_data/trajectory_plot.png')
    output_file.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"Trajectory plot saved as '{output_file}'")
    print(f"Total points: {len(x_coords)}")
    print(f"Start: ({x_coords[0]:.2f}, {y_coords[0]:.2f})")
    print(f"End: ({x_coords[-1]:.2f}, {y_coords[-1]:.2f})")

    plt.show()

if __name__ == "__main__":
    bag_path = "../_data"

    print("Reading odometry data from ROS bag...")
    x_coords, y_coords = read_bag(bag_path)

    print("Saving trajectory data to CSV...")
    save_to_csv(x_coords, y_coords)

    print("Plotting trajectory...")
    plot_trajectory(x_coords, y_coords)
