#!/usr/bin/env python3
"""
Core LiDAR Odometry Library

Shared functionality for both offline and live LiDAR odometry processing.
This module contains the common classes and utility functions used by both
lidar_odometry.py and lidar_odometry_live.py.
"""

import numpy as np
import open3d as o3d
from pathlib import Path
from rosbags.highlevel import AnyReader
from rosbags.typesys import get_typestore, Stores
from scipy.spatial.transform import Rotation as R
import pandas as pd
import struct
import configparser
from collections import deque


def read_tf_static(bag_path, parent_frame='base_link', child_frame='lidar_nav'):
    """
    Read static transform from /tf_static topic.

    Args:
        bag_path: Path to ROS2 bag directory
        parent_frame: Parent frame ID
        child_frame: Child frame ID

    Returns:
        4x4 transformation matrix from parent to child, or None if not found
    """
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with AnyReader([bag_path], default_typestore=typestore) as reader:
        tf_static_conns = [c for c in reader.connections if c.topic == '/tf_static']

        if not tf_static_conns:
            return None

        for connection, timestamp, rawdata in reader.messages(connections=tf_static_conns):
            msg = reader.deserialize(rawdata, connection.msgtype)

            for tf in msg.transforms:
                if tf.header.frame_id == parent_frame and tf.child_frame_id == child_frame:
                    # Extract translation
                    t = tf.transform.translation
                    trans = np.array([t.x, t.y, t.z])

                    # Extract rotation (quaternion)
                    q = tf.transform.rotation
                    rot = R.from_quat([q.x, q.y, q.z, q.w])

                    # Build 4x4 transformation matrix
                    transform = np.eye(4)
                    transform[:3, :3] = rot.as_matrix()
                    transform[:3, 3] = trans

                    return transform

    return None


class IMUIntegrator:
    """
    IMU data integration for motion prediction.

    Integrates angular velocity from IMU to predict rotation between scans,
    providing better initial guess for ICP.
    """

    def __init__(self, window_size=10):
        """
        Initialize IMU integrator.

        Args:
            window_size: Number of IMU measurements to average
        """
        self.angular_velocity_buffer = deque(maxlen=window_size)
        self.last_timestamp = None

    def add_measurement(self, angular_vel_z, timestamp):
        """
        Add an IMU measurement.

        Args:
            angular_vel_z: Angular velocity around z-axis (rad/s)
            timestamp: Measurement timestamp (seconds)
        """
        self.angular_velocity_buffer.append(angular_vel_z)
        self.last_timestamp = timestamp

    def predict_rotation(self, dt):
        """
        Predict rotation over time interval.

        Args:
            dt: Time interval (seconds)

        Returns:
            Predicted yaw change (radians)
        """
        if len(self.angular_velocity_buffer) == 0:
            return 0.0

        # Use mean angular velocity
        avg_angular_vel = np.mean(list(self.angular_velocity_buffer))
        return avg_angular_vel * dt

    def get_rotation_matrix(self, dt):
        """
        Get predicted rotation as 4x4 transformation matrix.

        Args:
            dt: Time interval (seconds)

        Returns:
            4x4 transformation matrix with predicted rotation
        """
        yaw = self.predict_rotation(dt)

        # Create rotation matrix around z-axis
        cos_yaw = np.cos(yaw)
        sin_yaw = np.sin(yaw)

        transform = np.eye(4)
        transform[0, 0] = cos_yaw
        transform[0, 1] = -sin_yaw
        transform[1, 0] = sin_yaw
        transform[1, 1] = cos_yaw

        return transform


class LiDAROdometry:
    """
    LiDAR-based odometry estimator using ICP scan matching.

    This class provides the core odometry estimation functionality using
    wall features and point-to-plane ICP matching.
    """

    def __init__(self, config=None):
        """
        Initialize the odometry estimator.

        Args:
            config: Dictionary with configuration parameters
        """
        # Default configuration
        self.config = {
            'height_min': 0.3,          # Min height for wall detection (m)
            'height_max': 2.0,          # Max height for wall detection (m)
            'voxel_size': 0.1,          # Voxel size for downsampling (m)
            'icp_threshold': 0.5,       # ICP distance threshold (m)
            'icp_max_iter': 50,         # Max ICP iterations
            'min_points': 100,          # Minimum points required for matching
            'outlier_nb_neighbors': 20, # Neighbors for outlier removal
            'outlier_std_ratio': 2.0,   # Std ratio for outlier removal
            'normal_radius': 0.5,       # Radius for normal estimation
            'normal_max_nn': 30,        # Max neighbors for normal estimation
            'use_imu': False,           # Enable IMU integration
            'imu_window_size': 10,      # IMU averaging window
            'use_tf_static': False,     # Use static transforms
            'lidar_to_base_tf': None,   # Transform from LiDAR to base_link
        }

        if config:
            self.config.update(config)

        # State variables
        self.trajectory = []
        self.timestamps = []
        self.current_pose = np.eye(4)  # 4x4 transformation matrix
        self.prev_cloud = None
        self.prev_timestamp = None

        # IMU integrator
        self.imu_integrator = None
        if self.config.get('use_imu', False):
            self.imu_integrator = IMUIntegrator(
                window_size=self.config.get('imu_window_size', 10)
            )

        # Static transform from LiDAR to base_link
        self.lidar_to_base = self.config.get('lidar_to_base_tf', None)

    def preprocess_pointcloud(self, points):
        """
        Preprocess point cloud: filter by height, downsample, remove outliers.

        Args:
            points: Nx3 numpy array of point coordinates

        Returns:
            open3d.geometry.PointCloud object (downsampled and filtered)
        """
        # Transform points from LiDAR frame to base_link frame if transform available
        if self.lidar_to_base is not None:
            # Convert to homogeneous coordinates
            ones = np.ones((points.shape[0], 1))
            points_homogeneous = np.hstack([points, ones])

            # Apply transformation
            points_transformed = (self.lidar_to_base @ points_homogeneous.T).T

            # Back to 3D coordinates
            points = points_transformed[:, :3]

        # Filter by height (extract wall-level points)
        mask = (points[:, 2] >= self.config['height_min']) & \
               (points[:, 2] <= self.config['height_max'])
        filtered_points = points[mask]

        if len(filtered_points) < self.config['min_points']:
            return None

        # Create Open3D point cloud
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(filtered_points)

        # Downsample using voxel grid
        pcd = pcd.voxel_down_sample(voxel_size=self.config['voxel_size'])

        # Remove statistical outliers
        pcd, _ = pcd.remove_statistical_outlier(
            nb_neighbors=self.config['outlier_nb_neighbors'],
            std_ratio=self.config['outlier_std_ratio']
        )

        return pcd

    def add_imu_measurement(self, angular_vel_z, timestamp):
        """
        Add IMU measurement for motion prediction.

        Args:
            angular_vel_z: Angular velocity around z-axis (rad/s)
            timestamp: Measurement timestamp (seconds)
        """
        if self.imu_integrator is not None:
            self.imu_integrator.add_measurement(angular_vel_z, timestamp)

    def estimate_transform_icp(self, source, target, dt=None):
        """
        Estimate transformation between two point clouds using ICP.

        Args:
            source: Open3D point cloud (current scan)
            target: Open3D point cloud (previous scan)
            dt: Time delta for IMU prediction (seconds), optional

        Returns:
            4x4 transformation matrix, fitness score
        """
        # Initial alignment guess
        trans_init = np.eye(4)

        # Use IMU prediction as initial guess if available
        if self.imu_integrator is not None and dt is not None:
            trans_init = self.imu_integrator.get_rotation_matrix(dt)

        # Point-to-plane ICP (better for planar surfaces like walls)
        # Estimate normals for point-to-plane ICP
        target.estimate_normals(
            search_param=o3d.geometry.KDTreeSearchParamHybrid(
                radius=self.config['normal_radius'],
                max_nn=self.config['normal_max_nn']
            )
        )
        source.estimate_normals(
            search_param=o3d.geometry.KDTreeSearchParamHybrid(
                radius=self.config['normal_radius'],
                max_nn=self.config['normal_max_nn']
            )
        )

        # Run ICP
        reg_result = o3d.pipelines.registration.registration_icp(
            source, target,
            self.config['icp_threshold'],
            trans_init,
            o3d.pipelines.registration.TransformationEstimationPointToPlane(),
            o3d.pipelines.registration.ICPConvergenceCriteria(
                max_iteration=self.config['icp_max_iter']
            )
        )

        return reg_result.transformation, reg_result.fitness

    def process_scan(self, points, timestamp):
        """
        Process a single LiDAR scan and update odometry estimate.

        Args:
            points: Nx3 numpy array of point coordinates
            timestamp: Scan timestamp (seconds)

        Returns:
            Current pose as (x, y, yaw) or None if processing failed
        """
        # Preprocess point cloud
        current_cloud = self.preprocess_pointcloud(points)

        if current_cloud is None:
            return None

        # First scan - just store it
        if self.prev_cloud is None:
            self.prev_cloud = current_cloud
            self.prev_timestamp = timestamp
            self.timestamps.append(timestamp)
            pose_2d = self.extract_2d_pose(self.current_pose)
            self.trajectory.append(pose_2d)
            return pose_2d

        # Calculate time delta for IMU prediction
        dt = timestamp - self.prev_timestamp if self.prev_timestamp is not None else None

        # Estimate transformation using ICP (with IMU initial guess if available)
        transformation, fitness = self.estimate_transform_icp(current_cloud, self.prev_cloud, dt)

        # Update global pose
        self.current_pose = self.current_pose @ transformation

        # Extract 2D pose (x, y, yaw)
        pose_2d = self.extract_2d_pose(self.current_pose)

        # Store trajectory
        self.trajectory.append(pose_2d)
        self.timestamps.append(timestamp)

        # Update previous cloud and timestamp
        self.prev_cloud = current_cloud
        self.prev_timestamp = timestamp

        return pose_2d

    def extract_2d_pose(self, transformation_matrix):
        """
        Extract 2D pose (x, y, yaw) from 4x4 transformation matrix.

        Args:
            transformation_matrix: 4x4 numpy array

        Returns:
            Tuple (x, y, yaw) where yaw is in radians
        """
        x = transformation_matrix[0, 3]
        y = transformation_matrix[1, 3]

        # Extract yaw from rotation matrix
        rotation = R.from_matrix(transformation_matrix[:3, :3])
        euler = rotation.as_euler('xyz', degrees=False)
        yaw = euler[2]  # Yaw is rotation around z-axis

        return (x, y, yaw)

    def get_trajectory(self):
        """
        Get the estimated trajectory.

        Returns:
            numpy array of shape (N, 3) with columns [x, y, yaw]
        """
        return np.array(self.trajectory)

    def save_trajectory(self, filepath):
        """
        Save trajectory to CSV file.

        Args:
            filepath: Path to output CSV file
        """
        # Ensure output directory exists
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)

        trajectory_array = self.get_trajectory()
        df = pd.DataFrame({
            'timestamp': self.timestamps,
            'x': trajectory_array[:, 0],
            'y': trajectory_array[:, 1],
            'yaw': trajectory_array[:, 2]
        })
        df.to_csv(filepath, index=False)
        print(f"Trajectory saved to {filepath}")


def extract_points_from_pointcloud2(msg):
    """
    Extract XYZ points from sensor_msgs/PointCloud2 message.

    Args:
        msg: PointCloud2 message

    Returns:
        Nx3 numpy array of points
    """
    # Get point step and offsets
    point_step = msg.point_step

    # Find x, y, z field offsets
    x_offset = None
    y_offset = None
    z_offset = None

    for field in msg.fields:
        if field.name == 'x':
            x_offset = field.offset
        elif field.name == 'y':
            y_offset = field.offset
        elif field.name == 'z':
            z_offset = field.offset

    if x_offset is None or y_offset is None or z_offset is None:
        return None

    # Parse binary data
    points = []
    data = msg.data

    for i in range(0, len(data), point_step):
        if i + point_step <= len(data):
            x = struct.unpack_from('f', data, i + x_offset)[0]
            y = struct.unpack_from('f', data, i + y_offset)[0]
            z = struct.unpack_from('f', data, i + z_offset)[0]

            # Filter out invalid points
            if not (np.isnan(x) or np.isnan(y) or np.isnan(z)):
                points.append([x, y, z])

    return np.array(points) if points else None


def count_lidar_messages(bag_path, topic='/livox/amr/lidar'):
    """
    Count total number of LiDAR messages in bag.

    Args:
        bag_path: Path to the ROS2 bag directory
        topic: LiDAR topic name

    Returns:
        Total count of LiDAR messages
    """
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with AnyReader([bag_path], default_typestore=typestore) as reader:
        lidar_connections = [c for c in reader.connections if c.topic == topic]
        if not lidar_connections:
            return 0

        count = 0
        for connection, timestamp, rawdata in reader.messages(connections=lidar_connections):
            count += 1

        return count


def read_rosbag(bag_path, topic='/livox/amr/lidar'):
    """
    Read LiDAR data from ROS2 bag.

    Args:
        bag_path: Path to the ROS2 bag directory
        topic: LiDAR topic name

    Yields:
        Tuple of (timestamp, points) where points is Nx3 numpy array
    """
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with AnyReader([bag_path], default_typestore=typestore) as reader:
        # Get connections for LiDAR topic
        lidar_connections = [c for c in reader.connections if c.topic == topic]

        if not lidar_connections:
            print(f"Warning: No LiDAR topic '{topic}' found in bag file")
            return

        print(f"Reading LiDAR data from {bag_path}")

        # Read messages
        for connection, timestamp, rawdata in reader.messages(connections=lidar_connections):
            msg = reader.deserialize(rawdata, connection.msgtype)

            # Extract point cloud data
            points = extract_points_from_pointcloud2(msg)

            if points is not None and len(points) > 0:
                # Convert timestamp to seconds
                timestamp_sec = timestamp / 1e9
                yield timestamp_sec, points


def read_imu_data(bag_path, topic='/livox/amr/imu'):
    """
    Read IMU data from ROS2 bag.

    Args:
        bag_path: Path to the ROS2 bag directory
        topic: IMU topic name

    Yields:
        Tuple of (timestamp, angular_vel_z) where angular_vel_z is in rad/s
    """
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with AnyReader([bag_path], default_typestore=typestore) as reader:
        # Get connections for IMU topic
        imu_connections = [c for c in reader.connections if c.topic == topic]

        if not imu_connections:
            print(f"Warning: No IMU topic '{topic}' found in bag file")
            return

        print(f"Reading IMU data from {topic}...")

        # Read messages
        for connection, timestamp, rawdata in reader.messages(connections=imu_connections):
            msg = reader.deserialize(rawdata, connection.msgtype)

            # Extract angular velocity around z-axis (yaw rate)
            angular_vel_z = msg.angular_velocity.z

            # Convert timestamp to seconds
            timestamp_sec = timestamp / 1e9
            yield timestamp_sec, angular_vel_z


def read_synchronized_data(bag_path, lidar_topic='/livox/amr/lidar', imu_topic='/livox/amr/imu'):
    """
    Read synchronized LiDAR and IMU data from ROS2 bag.

    This generator yields LiDAR scans and buffers IMU measurements between scans.

    Args:
        bag_path: Path to the ROS2 bag directory
        lidar_topic: LiDAR topic name
        imu_topic: IMU topic name

    Yields:
        Tuple of (timestamp, points, imu_measurements) where:
        - timestamp: LiDAR scan timestamp (seconds)
        - points: Nx3 numpy array of points
        - imu_measurements: List of (imu_timestamp, angular_vel_z) tuples since last scan
    """
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with AnyReader([bag_path], default_typestore=typestore) as reader:
        # Get connections
        lidar_connections = [c for c in reader.connections if c.topic == lidar_topic]
        imu_connections = [c for c in reader.connections if c.topic == imu_topic]

        if not lidar_connections:
            print(f"Warning: No LiDAR topic '{lidar_topic}' found in bag file")
            return

        print(f"Reading synchronized LiDAR and IMU data...")

        # Buffer for IMU measurements between LiDAR scans
        imu_buffer = []

        # Read all messages sorted by timestamp
        all_connections = lidar_connections + imu_connections

        for connection, timestamp, rawdata in reader.messages(connections=all_connections):
            msg = reader.deserialize(rawdata, connection.msgtype)
            timestamp_sec = timestamp / 1e9

            if connection.topic == imu_topic:
                # Buffer IMU measurement
                angular_vel_z = msg.angular_velocity.z
                imu_buffer.append((timestamp_sec, angular_vel_z))

            elif connection.topic == lidar_topic:
                # Extract point cloud
                points = extract_points_from_pointcloud2(msg)

                if points is not None and len(points) > 0:
                    # Yield LiDAR scan with buffered IMU measurements
                    yield timestamp_sec, points, imu_buffer.copy()
                    # Clear buffer for next scan
                    imu_buffer.clear()


def load_config(config_path='config.ini'):
    """
    Load configuration from INI file.

    Args:
        config_path: Path to config.ini file

    Returns:
        Tuple of (config_dict, paths) or None if config file not found
    """
    config = configparser.ConfigParser()
    script_dir = Path(__file__).parent
    config_file = script_dir / config_path

    if not config_file.exists():
        print(f"Warning: Config file not found at {config_file}, using defaults")
        return None

    config.read(config_file)

    # Parse configuration into dictionary
    config_dict = {
        'height_min': config.getfloat('preprocessing', 'height_min', fallback=0.3),
        'height_max': config.getfloat('preprocessing', 'height_max', fallback=2.0),
        'voxel_size': config.getfloat('preprocessing', 'voxel_size', fallback=0.1),
        'min_points': config.getint('preprocessing', 'min_points', fallback=100),
        'icp_threshold': config.getfloat('icp', 'icp_threshold', fallback=0.5),
        'icp_max_iter': config.getint('icp', 'icp_max_iter', fallback=50),
        'use_imu': config.getboolean('imu', 'use_imu', fallback=False),
        'imu_window_size': config.getint('imu', 'imu_window_size', fallback=10),
        'use_tf_static': config.getboolean('tf', 'use_tf_static', fallback=False),
        'outlier_nb_neighbors': config.getint('advanced', 'outlier_nb_neighbors', fallback=20),
        'outlier_std_ratio': config.getfloat('advanced', 'outlier_std_ratio', fallback=2.0),
        'normal_radius': config.getfloat('advanced', 'normal_radius', fallback=0.5),
        'normal_max_nn': config.getint('advanced', 'normal_max_nn', fallback=30),
    }

    # Also return paths
    paths = {
        'bag_path': config.get('paths', 'bag_path', fallback='../_data'),
        'output_dir': config.get('paths', 'output_dir', fallback='../results'),
        'trajectory_file': config.get('paths', 'trajectory_file', fallback='trajectory_estimated.csv'),
        'imu_topic': config.get('imu', 'imu_topic', fallback='/livox/amr/imu'),
        'lidar_topic': config.get('paths', 'lidar_topic', fallback='/livox/amr/lidar'),
        'base_frame': config.get('tf', 'base_frame', fallback='base_link'),
        'lidar_frame': config.get('tf', 'lidar_frame', fallback='lidar_nav'),
    }

    # Load static transform if requested
    if config_dict['use_tf_static']:
        bag_path = script_dir / paths['bag_path']
        base_frame = paths['base_frame']
        lidar_frame = paths['lidar_frame']

        print(f"Loading static transform: {base_frame} -> {lidar_frame}")
        tf_matrix = read_tf_static(bag_path, base_frame, lidar_frame)

        if tf_matrix is not None:
            config_dict['lidar_to_base_tf'] = tf_matrix
            print(f"  ✓ Transform loaded successfully")
        else:
            print(f"  ✗ Warning: Transform not found, operating in LiDAR frame")
            config_dict['use_tf_static'] = False

    return config_dict, paths
