#!/usr/bin/env python3
"""
Inspect ROS bag contents - shows available topics and message counts.
Useful for verifying bag file structure before processing.
"""

from rosbags.rosbag2 import Reader
from pathlib import Path
from collections import defaultdict


def inspect_bag(bag_path):
    """
    Inspect ROS bag and display contents.

    Args:
        bag_path: Path to ROS2 bag directory
    """
    print("="*70)
    print(f"ROS Bag Inspector: {bag_path}")
    print("="*70)

    with Reader(bag_path) as reader:
        # Print metadata
        print(f"\nDuration: {reader.duration / 1e9:.2f} seconds")
        print(f"Message count: {reader.message_count}")
        print(f"Start time: {reader.start_time / 1e9:.2f}")
        print(f"End time: {reader.end_time / 1e9:.2f}")

        # Count messages per topic
        topic_counts = defaultdict(int)
        topic_types = {}

        for connection in reader.connections:
            topic_types[connection.topic] = connection.msgtype

        for connection, timestamp, rawdata in reader.messages():
            topic_counts[connection.topic] += 1

        # Display topics
        print(f"\nTopics ({len(topic_counts)}):")
        print("-" * 70)
        print(f"{'Topic':<30} {'Type':<30} {'Count':>10}")
        print("-" * 70)

        for topic in sorted(topic_counts.keys()):
            msg_type = topic_types[topic].split('/')[-1] if topic in topic_types else 'Unknown'
            count = topic_counts[topic]
            print(f"{topic:<30} {msg_type:<30} {count:>10}")

        print("-" * 70)

        # Check for required topics
        print("\nRequired topics check:")
        required = {
            '/livox/amr/lidar': 'LiDAR data',
            '/tf': 'Transforms (for ground truth)',
        }

        for topic, description in required.items():
            status = "✓ FOUND" if topic in topic_counts else "✗ MISSING"
            print(f"  {status:12} {topic:30} - {description}")

        print("\n" + "="*70)


def main():
    """Main function."""
    import argparse

    parser = argparse.ArgumentParser(description='Inspect ROS bag contents')
    parser.add_argument('--bag', type=str, default='../_data',
                        help='Path to ROS bag directory')

    args = parser.parse_args()

    bag_path = Path(__file__).parent / args.bag

    if not bag_path.exists():
        print(f"ERROR: Bag path not found: {bag_path}")
        return

    inspect_bag(bag_path)


if __name__ == '__main__':
    main()
