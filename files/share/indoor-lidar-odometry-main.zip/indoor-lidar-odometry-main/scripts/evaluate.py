"""
Evaluation script for LiDAR odometry.

Computes:
1. Absolute Trajectory Error (ATE)
2. Yaw Error
3. Generates comparison plots
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from scipy.spatial.transform import Rotation as R
from rosbags.highlevel import AnyReader
from rosbags.typesys import get_typestore, Stores
import argparse
import configparser


def read_ground_truth_from_bag(bag_path, topic='/tf', parent_frame='odom', child_frame='base_link'):
    """
    Extract ground truth trajectory from ROS bag /tf topic.

    Args:
        bag_path: Path to ROS2 bag directory
        topic: TF topic name
        parent_frame: Parent frame ID (default: 'odom')
        child_frame: Child frame ID (default: 'base_link')

    Returns:
        DataFrame with columns [timestamp, x, y, yaw]
    """
    trajectory_data = []
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with AnyReader([bag_path], default_typestore=typestore) as reader:
        # Find TF connections
        tf_connections = [c for c in reader.connections if c.topic == topic]

        if not tf_connections:
            print(f"Warning: No {topic} topic found")
            return None

        print(f"Reading ground truth from {topic}...")

        for connection, timestamp, rawdata in reader.messages(connections=tf_connections):
            msg = reader.deserialize(rawdata, connection.msgtype)

            # Look for parent_frame -> child_frame transform
            for transform in msg.transforms:
                if (transform.header.frame_id == parent_frame and
                    transform.child_frame_id == child_frame):

                    # Extract position
                    x = transform.transform.translation.x
                    y = transform.transform.translation.y

                    # Extract orientation (quaternion to yaw)
                    quat = transform.transform.rotation
                    rotation = R.from_quat([quat.x, quat.y, quat.z, quat.w])
                    yaw = rotation.as_euler('xyz')[2]

                    timestamp_sec = timestamp / 1e9

                    trajectory_data.append({
                        'timestamp': timestamp_sec,
                        'x': x,
                        'y': y,
                        'yaw': yaw
                    })

    if not trajectory_data:
        return None

    df = pd.DataFrame(trajectory_data)
    # Remove duplicates and sort by timestamp
    df = df.drop_duplicates(subset=['timestamp']).sort_values('timestamp').reset_index(drop=True)

    return df


def align_trajectories(est_df, gt_df):
    """
    Align estimated trajectory with ground truth by timestamp interpolation.

    Args:
        est_df: Estimated trajectory DataFrame
        gt_df: Ground truth trajectory DataFrame

    Returns:
        Tuple of (aligned_est, aligned_gt) DataFrames
    """
    # Find common time range
    t_start = max(est_df['timestamp'].min(), gt_df['timestamp'].min())
    t_end = min(est_df['timestamp'].max(), gt_df['timestamp'].max())

    # Filter to common range
    est_aligned = est_df[(est_df['timestamp'] >= t_start) &
                         (est_df['timestamp'] <= t_end)].copy()
    gt_aligned = gt_df[(gt_df['timestamp'] >= t_start) &
                       (gt_df['timestamp'] <= t_end)].copy()

    # Interpolate ground truth to match estimated timestamps
    gt_interp = pd.DataFrame()
    gt_interp['timestamp'] = est_aligned['timestamp']
    gt_interp['x'] = np.interp(est_aligned['timestamp'], gt_aligned['timestamp'], gt_aligned['x'])
    gt_interp['y'] = np.interp(est_aligned['timestamp'], gt_aligned['timestamp'], gt_aligned['y'])

    # Interpolate yaw (handle angle wrapping)
    yaw_unwrapped = np.unwrap(gt_aligned['yaw'])
    yaw_interp = np.interp(est_aligned['timestamp'], gt_aligned['timestamp'], yaw_unwrapped)
    gt_interp['yaw'] = yaw_interp

    return est_aligned.reset_index(drop=True), gt_interp.reset_index(drop=True)


def compute_ate(est_df, gt_df):
    """
    Compute Absolute Trajectory Error (ATE).

    Args:
        est_df: Estimated trajectory DataFrame (aligned)
        gt_df: Ground truth trajectory DataFrame (aligned)

    Returns:
        Dictionary with ATE statistics
    """
    # Compute position errors
    dx = est_df['x'].values - gt_df['x'].values
    dy = est_df['y'].values - gt_df['y'].values
    errors = np.sqrt(dx**2 + dy**2)

    ate_stats = {
        'mean': np.mean(errors),
        'median': np.median(errors),
        'std': np.std(errors),
        'min': np.min(errors),
        'max': np.max(errors),
        'rmse': np.sqrt(np.mean(errors**2)),
        'errors': errors
    }

    return ate_stats


def compute_yaw_error(est_df, gt_df):
    """
    Compute yaw angle error.

    Args:
        est_df: Estimated trajectory DataFrame (aligned)
        gt_df: Ground truth trajectory DataFrame (aligned)

    Returns:
        Dictionary with yaw error statistics (in degrees)
    """
    # Compute angular difference
    yaw_diff = est_df['yaw'].values - gt_df['yaw'].values

    # Normalize to [-pi, pi]
    yaw_diff = np.arctan2(np.sin(yaw_diff), np.cos(yaw_diff))

    # Convert to degrees
    yaw_diff_deg = np.degrees(yaw_diff)

    yaw_stats = {
        'mean_abs': np.mean(np.abs(yaw_diff_deg)),
        'mean': np.mean(yaw_diff_deg),
        'std': np.std(yaw_diff_deg),
        'min': np.min(yaw_diff_deg),
        'max': np.max(yaw_diff_deg),
        'rmse': np.sqrt(np.mean(yaw_diff_deg**2)),
        'errors': yaw_diff_deg
    }

    return yaw_stats


def plot_trajectories(est_df, gt_df, output_path):
    """
    Plot estimated vs ground truth trajectories.

    Args:
        est_df: Estimated trajectory DataFrame
        gt_df: Ground truth trajectory DataFrame
        output_path: Path to save the plot
    """
    plt.figure(figsize=(12, 10))

    # Plot trajectories
    plt.plot(gt_df['x'], gt_df['y'], 'b-', linewidth=2, label='Ground Truth', alpha=0.7)
    plt.plot(est_df['x'], est_df['y'], 'r--', linewidth=2, label='Estimated', alpha=0.7)

    # Mark start and end points
    plt.plot(gt_df['x'].iloc[0], gt_df['y'].iloc[0], 'go', markersize=12, label='Start')
    plt.plot(gt_df['x'].iloc[-1], gt_df['y'].iloc[-1], 'rs', markersize=12, label='End')

    plt.xlabel('X (m)', fontsize=12)
    plt.ylabel('Y (m)', fontsize=12)
    plt.title('2D Trajectory Comparison', fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.axis('equal')
    plt.tight_layout()

    # Ensure output directory exists
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"Trajectory plot saved to {output_path}")
    plt.close()


def plot_errors(ate_stats, yaw_stats, est_df, output_path):
    """
    Plot ATE and yaw errors over time.

    Args:
        ate_stats: ATE statistics dictionary
        yaw_stats: Yaw error statistics dictionary
        est_df: Estimated trajectory DataFrame (for timestamps)
        output_path: Path to save the plot
    """
    fig, axes = plt.subplots(2, 1, figsize=(14, 10))

    # Normalize time to start at 0
    time = est_df['timestamp'].values - est_df['timestamp'].values[0]

    # Plot ATE over time
    ax1 = axes[0]
    ax1.plot(time, ate_stats['errors'], 'b-', linewidth=1.5, alpha=0.7)
    ax1.axhline(y=ate_stats['mean'], color='r', linestyle='--',
                label=f'Mean: {ate_stats["mean"]:.3f}m', linewidth=2)
    ax1.fill_between(time, 0, ate_stats['errors'], alpha=0.2)
    ax1.set_xlabel('Time (s)', fontsize=12)
    ax1.set_ylabel('Position Error (m)', fontsize=12)
    ax1.set_title(f'Absolute Trajectory Error (ATE)\nRMSE: {ate_stats["rmse"]:.3f}m',
                  fontsize=13, fontweight='bold')
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)

    # Plot yaw error over time
    ax2 = axes[1]
    ax2.plot(time, yaw_stats['errors'], 'g-', linewidth=1.5, alpha=0.7)
    ax2.axhline(y=yaw_stats['mean'], color='r', linestyle='--',
                label=f'Mean: {yaw_stats["mean"]:.2f}°', linewidth=2)
    ax2.fill_between(time, 0, yaw_stats['errors'], alpha=0.2, color='green')
    ax2.set_xlabel('Time (s)', fontsize=12)
    ax2.set_ylabel('Yaw Error (degrees)', fontsize=12)
    ax2.set_title(f'Yaw Angle Error\nMean Absolute: {yaw_stats["mean_abs"]:.2f}°',
                  fontsize=13, fontweight='bold')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    # Ensure output directory exists
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"Error plot saved to {output_path}")
    plt.close()


def compute_runtime_stats(est_df):
    """
    Compute runtime statistics from timestamps.

    Args:
        est_df: Estimated trajectory DataFrame with timestamps

    Returns:
        Dictionary with runtime statistics
    """
    timestamps = est_df['timestamp'].values

    # Compute time deltas between consecutive frames
    time_deltas = np.diff(timestamps)

    # Compute frequencies (Hz)
    frequencies = 1.0 / time_deltas

    runtime_stats = {
        'mean_freq': np.mean(frequencies),
        'median_freq': np.median(frequencies),
        'std_freq': np.std(frequencies),
        'min_freq': np.min(frequencies),
        'max_freq': np.max(frequencies),
        'total_duration': timestamps[-1] - timestamps[0],
        'num_frames': len(timestamps),
    }

    return runtime_stats


def generate_report(ate_stats, yaw_stats, runtime_stats, output_path):
    """
    Generate a text report with evaluation metrics.

    Args:
        ate_stats: ATE statistics dictionary
        yaw_stats: Yaw error statistics dictionary
        runtime_stats: Runtime statistics dictionary
        output_path: Path to save the report
    """
    report = f"""
====================================================
    LiDAR Odometry Evaluation Report
====================================================

ABSOLUTE TRAJECTORY ERROR (ATE)
--------------------------------
RMSE:           {ate_stats['rmse']:.4f} m
Mean:           {ate_stats['mean']:.4f} m
Median:         {ate_stats['median']:.4f} m
Std Dev:        {ate_stats['std']:.4f} m
Min:            {ate_stats['min']:.4f} m
Max:            {ate_stats['max']:.4f} m

YAW ERROR
---------
Mean Absolute:  {yaw_stats['mean_abs']:.2f}°
RMSE:           {yaw_stats['rmse']:.2f}°
Mean:           {yaw_stats['mean']:.2f}°
Std Dev:        {yaw_stats['std']:.2f}°
Min:            {yaw_stats['min']:.2f}°
Max:            {yaw_stats['max']:.2f}°

RUNTIME PERFORMANCE
-------------------
Mean Frequency:     {runtime_stats['mean_freq']:.2f} Hz
Median Frequency:   {runtime_stats['median_freq']:.2f} Hz
Std Dev:            {runtime_stats['std_freq']:.2f} Hz
Min Frequency:      {runtime_stats['min_freq']:.2f} Hz
Max Frequency:      {runtime_stats['max_freq']:.2f} Hz
Total Duration:     {runtime_stats['total_duration']:.2f} s
Total Frames:       {runtime_stats['num_frames']}

====================================================
Algorithm: ICP-based scan matching with point-to-plane
Features: Wall detection via height filtering
====================================================
"""

    # Ensure output directory exists
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w') as f:
        f.write(report)

    print(report)
    print(f"Report saved to {output_path}")


def load_config(config_path='config.ini'):
    """
    Load configuration from INI file.

    Args:
        config_path: Path to config.ini file

    Returns:
        Dictionary with paths and evaluation parameters
    """
    config = configparser.ConfigParser()
    script_dir = Path(__file__).parent
    config_file = script_dir / config_path

    if not config_file.exists():
        print(f"Warning: Config file not found at {config_file}, using defaults")
        return None

    config.read(config_file)

    # Parse configuration
    paths = {
        'bag_path': config.get('paths', 'bag_path', fallback='../_data'),
        'output_dir': config.get('paths', 'output_dir', fallback='../results'),
        'trajectory_file': config.get('paths', 'trajectory_file', fallback='trajectory_estimated.csv'),
        'evaluation_report': config.get('paths', 'evaluation_report', fallback='evaluation_report.txt'),
        'trajectory_plot': config.get('paths', 'trajectory_plot', fallback='trajectory_comparison.png'),
        'error_plot': config.get('paths', 'error_plot', fallback='error_plot.png'),
    }

    eval_params = {
        'gt_topic': config.get('evaluation', 'gt_topic', fallback='/tf'),
        'gt_parent_frame': config.get('evaluation', 'gt_parent_frame', fallback='odom'),
        'gt_child_frame': config.get('evaluation', 'gt_child_frame', fallback='base_link'),
    }

    return paths, eval_params


def main():
    parser = argparse.ArgumentParser(description='Evaluate LiDAR odometry results')
    parser.add_argument('--estimated', type=str,
                        help='Path to estimated trajectory CSV (overrides config)')
    parser.add_argument('--bag', type=str,
                        help='Path to ROS bag directory (overrides config)')
    parser.add_argument('--output-dir', type=str,
                        help='Directory to save evaluation results (overrides config)')
    parser.add_argument('--config', type=str, default='config.ini',
                        help='Path to configuration file')

    args = parser.parse_args()

    # Load configuration
    config_result = load_config(args.config)
    script_dir = Path(__file__).parent

    if config_result:
        paths, eval_params = config_result
        # Use command line args if provided, otherwise use config
        est_path = script_dir / args.estimated if args.estimated else script_dir / paths['output_dir'] / paths['trajectory_file']
        bag_path = script_dir / args.bag if args.bag else script_dir / paths['bag_path']
        output_dir = script_dir / args.output_dir if args.output_dir else script_dir / paths['output_dir']
    else:
        # Fallback to command line args or defaults
        est_path = script_dir / (args.estimated or '../results/trajectory_estimated.csv')
        bag_path = script_dir / (args.bag or '../_data')
        output_dir = script_dir / (args.output_dir or '../results')
        eval_params = {
            'gt_topic': '/tf',
            'gt_parent_frame': 'odom',
            'gt_child_frame': 'base_link',
        }

    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("LiDAR Odometry Evaluation")
    print("=" * 60)

    # Load estimated trajectory
    print(f"\n1. Loading estimated trajectory from {est_path}...")
    est_df = pd.read_csv(est_path)
    print(f"   Loaded {len(est_df)} estimated poses")

    # Load ground truth
    print("\n2. Loading ground truth from ROS bag...")
    gt_df = read_ground_truth_from_bag(
        bag_path,
        topic=eval_params['gt_topic'],
        parent_frame=eval_params['gt_parent_frame'],
        child_frame=eval_params['gt_child_frame']
    )

    if gt_df is None:
        print("ERROR: Could not extract ground truth from bag file")
        return

    print(f"   Loaded {len(gt_df)} ground truth poses")

    # Align trajectories
    print("\n3. Aligning trajectories...")
    est_aligned, gt_aligned = align_trajectories(est_df, gt_df)
    print(f"   Aligned to {len(est_aligned)} common poses")

    # Compute metrics
    print("\n4. Computing evaluation metrics...")
    ate_stats = compute_ate(est_aligned, gt_aligned)
    yaw_stats = compute_yaw_error(est_aligned, gt_aligned)
    runtime_stats = compute_runtime_stats(est_aligned)

    # Generate plots
    print("\n5. Generating plots...")
    if config_result:
        trajectory_plot_name = paths['trajectory_plot']
        error_plot_name = paths['error_plot']
        report_name = paths['evaluation_report']
    else:
        trajectory_plot_name = 'trajectory_comparison.png'
        error_plot_name = 'error_plot.png'
        report_name = 'evaluation_report.txt'

    plot_trajectories(est_aligned, gt_aligned, output_dir / trajectory_plot_name)
    plot_errors(ate_stats, yaw_stats, est_aligned, output_dir / error_plot_name)

    # Generate report
    print("\n6. Generating report...")
    generate_report(ate_stats, yaw_stats, runtime_stats, output_dir / report_name)

    print("\n" + "=" * 60)
    print("Evaluation complete!")
    print("=" * 60)


if __name__ == '__main__':
    main()
