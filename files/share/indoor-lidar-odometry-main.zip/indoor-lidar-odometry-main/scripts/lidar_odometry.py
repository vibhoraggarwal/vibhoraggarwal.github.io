#!/usr/bin/env python3
"""
LiDAR Odometry Estimator for Indoor Environments

This script processes ROS bag data containing LiDAR scans and estimates
the robot's 2D trajectory using ICP-based scan matching.
"""

import numpy as np
from pathlib import Path
from tqdm import tqdm
import json

# Import shared core functionality
from lidar_odometry_core import (
    LiDAROdometry,
    load_config,
    read_rosbag,
    read_synchronized_data,
    count_lidar_messages
)


def main():
    """Main execution function."""
    # Load configuration from config.ini
    config_result = load_config('config.ini')

    if config_result:
        config, paths = config_result
        script_dir = Path(__file__).parent
        bag_path = script_dir / paths['bag_path']
        output_path = script_dir / paths['output_dir'] / paths['trajectory_file']
    else:
        # Fallback to hardcoded paths and default config
        bag_path = Path(__file__).parent.parent / '_data'
        output_path = Path(__file__).parent.parent / 'results' / 'trajectory_estimated.csv'
        config = {
            'height_min': 0.3,
            'height_max': 2.0,
            'voxel_size': 0.1,
            'icp_threshold': 0.5,
            'icp_max_iter': 50,
            'min_points': 100,
        }

    # Initialize odometry estimator
    odometry = LiDAROdometry(config)

    print("Starting LiDAR odometry estimation...")

    # Create a JSON-serializable config for display
    display_config = {k: v for k, v in config.items() if k != 'lidar_to_base_tf'}
    print(f"Configuration: {json.dumps(display_config, indent=2)}")
    print(f"Bag path: {bag_path}")
    print(f"Output path: {output_path}")

    # Display coordinate frame information
    if config.get('use_tf_static', False):
        print("\n✓ Using base_link coordinate frame (with static transforms)")
    else:
        print("\n⚠ Using LiDAR coordinate frame (no static transforms)")

    # Count total scans for progress bar
    print("\nCounting total scans in bag file...")
    total_scans = count_lidar_messages(bag_path)
    print(f"Found {total_scans} LiDAR scans")

    # Process ROS bag
    scan_count = 0

    if config.get('use_imu', False):
        # Process with IMU integration
        print("IMU integration enabled - using synchronized LiDAR + IMU data")
        lidar_topic = paths.get('lidar_topic', '/livox/amr/lidar')
        imu_topic = paths.get('imu_topic', '/livox/amr/imu')

        for timestamp, points, imu_measurements in tqdm(
            read_synchronized_data(bag_path, lidar_topic, imu_topic),
            total=total_scans,
            desc="Processing scans",
            unit="scan"
        ):
            # Add IMU measurements to odometry
            for imu_timestamp, angular_vel_z in imu_measurements:
                odometry.add_imu_measurement(angular_vel_z, imu_timestamp)

            # Process LiDAR scan
            pose = odometry.process_scan(points, timestamp)
            if pose is not None:
                scan_count += 1
                if scan_count % 10 == 0:
                    print(f"Scan {scan_count}: x={pose[0]:.2f}m, y={pose[1]:.2f}m, yaw={np.degrees(pose[2]):.1f}°")
    else:
        # Process LiDAR only (original behavior)
        print("IMU integration disabled - using LiDAR-only odometry")
        for timestamp, points in tqdm(read_rosbag(bag_path), total=total_scans, desc="Processing scans", unit="scan"):
            pose = odometry.process_scan(points, timestamp)
            if pose is not None:
                scan_count += 1
                if scan_count % 10 == 0:
                    print(f"Scan {scan_count}: x={pose[0]:.2f}m, y={pose[1]:.2f}m, yaw={np.degrees(pose[2]):.1f}°")

    # Save trajectory
    output_path.parent.mkdir(parents=True, exist_ok=True)
    odometry.save_trajectory(output_path)

    print(f"\nProcessed {scan_count} scans")
    print(f"Trajectory saved to {output_path}")

    # Print summary statistics
    trajectory = odometry.get_trajectory()
    if len(trajectory) > 0:
        print("\nTrajectory summary:")
        print(f"  Total distance traveled: {np.sum(np.linalg.norm(np.diff(trajectory[:, :2], axis=0), axis=1)):.2f}m")
        print(f"  X range: [{trajectory[:, 0].min():.2f}, {trajectory[:, 0].max():.2f}]m")
        print(f"  Y range: [{trajectory[:, 1].min():.2f}, {trajectory[:, 1].max():.2f}]m")


if __name__ == '__main__':
    main()
