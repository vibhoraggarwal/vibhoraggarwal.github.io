#!/usr/bin/env python3
"""
LiDAR Odometry with Live Visualization

This script processes ROS bag data and displays the estimated trajectory
alongside ground truth in real-time.
"""

import numpy as np
from pathlib import Path
from rosbags.highlevel import AnyReader
from rosbags.typesys import get_typestore, Stores
from scipy.spatial.transform import Rotation as R
import pandas as pd
from tqdm import tqdm
import json
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from collections import deque
import threading

# Import shared core functionality
from lidar_odometry_core import (
    LiDAROdometry,
    load_config,
    read_synchronized_data,
    read_rosbag,
    count_lidar_messages
)


def read_ground_truth_from_bag(bag_path, topic='/tf'):
    """
    Extract ground truth trajectory from ROS bag /tf topic.

    Args:
        bag_path: Path to ROS2 bag directory
        topic: TF topic name

    Returns:
        DataFrame with columns [timestamp, x, y, yaw]
    """
    trajectory_data = []
    typestore = get_typestore(Stores.ROS2_HUMBLE)

    with AnyReader([bag_path], default_typestore=typestore) as reader:
        # Find TF connections
        tf_connections = [c for c in reader.connections if c.topic == topic]

        if not tf_connections:
            return None

        print(f"Reading ground truth from {topic}...")

        for connection, timestamp, rawdata in reader.messages(connections=tf_connections):
            msg = reader.deserialize(rawdata, connection.msgtype)

            # Look for odom -> base_link transform
            for transform in msg.transforms:
                if (transform.header.frame_id == 'odom' and
                    transform.child_frame_id == 'base_link'):

                    # Extract position
                    x = transform.transform.translation.x
                    y = transform.transform.translation.y

                    # Extract orientation (quaternion to yaw)
                    quat = transform.transform.rotation
                    rotation = R.from_quat([quat.x, quat.y, quat.z, quat.w])
                    yaw = rotation.as_euler('xyz')[2]

                    timestamp_sec = timestamp / 1e9

                    trajectory_data.append({
                        'timestamp': timestamp_sec,
                        'x': x,
                        'y': y,
                        'yaw': yaw
                    })

    if not trajectory_data:
        return None

    df = pd.DataFrame(trajectory_data)
    df = df.drop_duplicates(subset=['timestamp']).sort_values('timestamp').reset_index(drop=True)

    return df


class LivePlotter:
    """
    Real-time trajectory plotter.
    """

    def __init__(self, gt_df=None):
        """
        Initialize live plotter.

        Args:
            gt_df: Ground truth DataFrame (optional)
        """
        self.gt_df = gt_df
        self.est_x = []
        self.est_y = []
        self.est_timestamps = []

        # Setup plot
        plt.ion()
        self.fig, self.ax = plt.subplots(figsize=(10, 8))

        # Plot ground truth if available
        if gt_df is not None:
            self.ax.plot(gt_df['x'], gt_df['y'], 'g-', label='Ground Truth', linewidth=2, alpha=0.7)

        # Initialize estimated trajectory line
        self.est_line, = self.ax.plot([], [], 'b-', label='Estimated', linewidth=2)
        self.est_point, = self.ax.plot([], [], 'ro', markersize=8, label='Current Position')

        self.ax.set_xlabel('X (m)', fontsize=12)
        self.ax.set_ylabel('Y (m)', fontsize=12)
        self.ax.set_title('LiDAR Odometry - Live Trajectory', fontsize=14, fontweight='bold')
        self.ax.legend(loc='best')
        self.ax.grid(True, alpha=0.3)
        self.ax.axis('equal')

        plt.tight_layout()
        plt.show(block=False)

    def update(self, x, y, timestamp):
        """
        Update plot with new position.

        Args:
            x: X coordinate
            y: Y coordinate
            timestamp: Timestamp
        """
        self.est_x.append(x)
        self.est_y.append(y)
        self.est_timestamps.append(timestamp)

        # Update estimated trajectory
        self.est_line.set_data(self.est_x, self.est_y)
        self.est_point.set_data([x], [y])

        # Auto-scale axes
        self.ax.relim()
        self.ax.autoscale_view()

        # Redraw
        self.fig.canvas.draw()
        self.fig.canvas.flush_events()
        plt.pause(0.001)

    def close(self):
        """Close the plot."""
        plt.ioff()
        plt.show()


def main():
    """Main execution function."""
    # Load configuration
    config_result = load_config('config.ini')
    script_dir = Path(__file__).parent

    if config_result:
        config, paths = config_result
        bag_path = script_dir / paths['bag_path']
        output_path = script_dir / paths['output_dir'] / paths['trajectory_file']
        lidar_topic = paths.get('lidar_topic', '/livox/amr/lidar')
        imu_topic = paths.get('imu_topic', '/livox/amr/imu')
    else:
        # Fallback to defaults
        bag_path = script_dir.parent / '_data'
        output_path = script_dir.parent / 'results' / 'trajectory_estimated.csv'
        lidar_topic = '/livox/amr/lidar'
        imu_topic = '/livox/amr/imu'
        config = {
            'height_min': 0.3,
            'height_max': 2.0,
            'voxel_size': 0.1,
            'icp_threshold': 0.5,
            'icp_max_iter': 50,
            'min_points': 100,
            'use_imu': False,
        }

    print("="*70)
    print("LiDAR Odometry with Live Visualization")
    print("="*70)

    # Load ground truth
    print("\n1. Loading ground truth...")
    gt_df = read_ground_truth_from_bag(bag_path)
    if gt_df is not None:
        print(f"   Loaded {len(gt_df)} ground truth poses")
    else:
        print("   No ground truth available")

    # Initialize odometry estimator
    odometry = LiDAROdometry(config)

    print("\n2. Starting LiDAR odometry estimation...")

    # Create a JSON-serializable config for display
    display_config = {k: v for k, v in config.items() if k != 'lidar_to_base_tf'}
    print(f"   Configuration: {json.dumps(display_config, indent=2)}")
    if config.get('use_imu', False):
        print("   IMU integration: ENABLED")
    else:
        print("   IMU integration: DISABLED")

    if config.get('use_tf_static', False):
        print("   ✓ Using base_link coordinate frame (with static transforms)")
    else:
        print("   ⚠ Using LiDAR coordinate frame (no static transforms)")

    # Count total scans for progress bar
    print("\n3. Counting total scans in bag file...")
    total_scans = count_lidar_messages(bag_path, lidar_topic)
    print(f"   Found {total_scans} LiDAR scans")

    # Initialize live plotter
    plotter = LivePlotter(gt_df)

    # Process ROS bag
    print("\n4. Processing scans...\n")
    scan_count = 0
    update_interval = 5  # Update plot every N scans for better performance

    if config.get('use_imu', False):
        # Process with IMU integration
        for timestamp, points, imu_measurements in tqdm(
            read_synchronized_data(bag_path, lidar_topic, imu_topic),
            total=total_scans,
            desc="Processing scans",
            unit="scan"
        ):
            # Add IMU measurements
            for imu_timestamp, angular_vel_z in imu_measurements:
                odometry.add_imu_measurement(angular_vel_z, imu_timestamp)

            # Process LiDAR scan
            pose = odometry.process_scan(points, timestamp)
            if pose is not None:
                scan_count += 1

                # Update plot periodically
                if scan_count % update_interval == 0:
                    plotter.update(pose[0], pose[1], timestamp)
    else:
        # Process LiDAR only
        for timestamp, points in tqdm(read_rosbag(bag_path, lidar_topic), total=total_scans, desc="Processing scans", unit="scan"):
            pose = odometry.process_scan(points, timestamp)
            if pose is not None:
                scan_count += 1

                # Update plot periodically
                if scan_count % update_interval == 0:
                    plotter.update(pose[0], pose[1], timestamp)

    # Final update
    if scan_count > 0:
        trajectory = odometry.get_trajectory()
        plotter.update(trajectory[-1, 0], trajectory[-1, 1], odometry.timestamps[-1])

    # Save trajectory
    output_path.parent.mkdir(parents=True, exist_ok=True)
    odometry.save_trajectory(output_path)

    print(f"\n{'='*70}")
    print("Processing Complete!")
    print(f"{'='*70}")
    print(f"Processed {scan_count} scans")
    print(f"Trajectory saved to {output_path}")

    # Print summary statistics
    trajectory = odometry.get_trajectory()
    if len(trajectory) > 0:
        print("\nTrajectory summary:")
        print(f"  Total distance traveled: {np.sum(np.linalg.norm(np.diff(trajectory[:, :2], axis=0), axis=1)):.2f}m")
        print(f"  X range: [{trajectory[:, 0].min():.2f}, {trajectory[:, 0].max():.2f}]m")
        print(f"  Y range: [{trajectory[:, 1].min():.2f}, {trajectory[:, 1].max():.2f}]m")

    print("\nClose the plot window to exit...")
    plotter.close()


if __name__ == '__main__':
    main()
