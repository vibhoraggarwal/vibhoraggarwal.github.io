#!/usr/bin/env python3
"""
Quick visualization script for trajectory data.
Can be used to quickly plot estimated and/or ground truth trajectories.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import argparse


def plot_trajectory_simple(csv_path, output_path=None, title="Trajectory"):
    """
    Simple trajectory plotting from CSV file.

    Args:
        csv_path: Path to CSV file with x, y columns
        output_path: Optional path to save figure
        title: Plot title
    """
    df = pd.read_csv(csv_path)

    plt.figure(figsize=(10, 10))
    plt.plot(df['x'], df['y'], 'b-', linewidth=2, alpha=0.7)
    plt.plot(df['x'].iloc[0], df['y'].iloc[0], 'go', markersize=12, label='Start')
    plt.plot(df['x'].iloc[-1], df['y'].iloc[-1], 'rs', markersize=12, label='End')

    plt.xlabel('X (m)', fontsize=12)
    plt.ylabel('Y (m)', fontsize=12)
    plt.title(title, fontsize=14, fontweight='bold')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.axis('equal')
    plt.tight_layout()

    if output_path:
        # Ensure output directory exists
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"Saved to {output_path}")
    else:
        plt.show()

    plt.close()


def main():
    parser = argparse.ArgumentParser(description='Visualize trajectory')
    parser.add_argument('trajectory', type=str, help='Path to trajectory CSV file')
    parser.add_argument('--output', type=str, help='Output plot path')
    parser.add_argument('--title', type=str, default='Trajectory', help='Plot title')

    args = parser.parse_args()

    plot_trajectory_simple(args.trajectory, args.output, args.title)


if __name__ == '__main__':
    main()
