# LiDAR Odometry Scripts

This directory contains the main scripts for running LiDAR odometry estimation and evaluation.

## Module Structure

### Core Library: `lidar_odometry_core.py`

Shared functionality used by both offline and live processing scripts:
- `LiDAROdometry` class: Main odometry estimation engine with optional IMU integration
- `IMUIntegrator` class: IMU data integration for motion prediction
- Point cloud preprocessing and filtering
- ICP-based scan matching with IMU-aided initialization
- Configuration loading
- ROS bag reading utilities (LiDAR, IMU, and synchronized data)

This modular design eliminates code duplication between `lidar_odometry.py` and `lidar_odometry_live.py`.

## Configuration

All scripts now use the `config.ini` file for default parameters.

### Configuration File: `config.ini`

The configuration file is divided into several sections:

#### `[preprocessing]`
- `height_min`, `height_max`: Height range for wall detection (meters)
- `voxel_size`: Downsampling resolution (meters)
- `min_points`: Minimum points required for scan processing

#### `[icp]`
- `icp_threshold`: Maximum distance for point correspondences (meters)
- `icp_max_iter`: Maximum ICP iterations

#### `[imu]`
- `use_imu`: Enable/disable IMU integration (true/false)
- `imu_topic`: IMU topic in ROS bag
- `imu_window_size`: Number of IMU measurements to average for prediction

#### `[tf]`
- `use_tf_static`: Enable/disable static transform usage (true/false)
- `base_frame`: Robot base frame (typically `base_link`)
- `lidar_frame`: LiDAR sensor frame (e.g., `lidar_nav_mount`)

#### `[paths]`
- `bag_path`: ROS bag directory path (relative to scripts/)
- `output_dir`: Output directory for results
- `trajectory_file`: Output trajectory filename
- `evaluation_report`: Evaluation report filename
- Plot filenames (trajectory_plot, error_plot, etc.)

#### `[advanced]`
- `outlier_nb_neighbors`, `outlier_std_ratio`: Statistical outlier removal parameters
- `normal_radius`, `normal_max_nn`: Normal estimation parameters for ICP

#### `[evaluation]`
- `gt_topic`: Ground truth topic in ROS bag
- `gt_parent_frame`, `gt_child_frame`: TF frame IDs for ground truth

## Scripts

### 1. `lidar_odometry.py`

Estimates robot trajectory from LiDAR scans using ICP-based scan matching.

**Usage:**
```bash
python lidar_odometry.py
```

**Output:**
- `results/trajectory_estimated.csv` - Estimated trajectory (timestamp, x, y, yaw)

### 2. `evaluate.py`

Evaluates estimated trajectory against ground truth.

**Usage:**
```bash
# Using config.ini
python evaluate.py

# Override config with command-line arguments
python evaluate.py --estimated ../results/trajectory_estimated.csv \
                   --bag ../_data \
                   --output-dir ../results

# Use a different config file
python evaluate.py --config custom_config.ini
```

**Command-line arguments:**
- `--estimated`: Override trajectory CSV path
- `--bag`: Override bag directory path
- `--output-dir`: Override output directory
- `--config`: Use different config file (default: config.ini)

**Outputs:**
- `results/trajectory_comparison.png` - Trajectory plot
- `results/error_plot.png` - Error over time plot
- `results/evaluation_report.txt` - Text report with metrics

### 3. `visualize.py`

Quick visualization tool for trajectory CSV files.

**Usage:**
```bash
# Display trajectory
python visualize.py ../results/trajectory_estimated.csv

# Save to file
python visualize.py ../results/trajectory_estimated.csv --output ../results/trajectory.png

# Custom title
python visualize.py ../results/trajectory_estimated.csv --title "My Trajectory"
```

**Arguments:**
- `trajectory`: Path to trajectory CSV file
- `--output`: Output plot path (optional, shows plot if not specified)
- `--title`: Plot title (default: "Trajectory")

### 4. `inspect_bag.py`

Utility to inspect ROS bag contents.

### 5. `extract_and_plot.py`

Extracting and plotting trajectory data.

### 6. `lidar_odometry_live.py`

Real-time odometry estimation (if available).

## Workflow

### Standard Usage

1. **Configure the algorithm**
   ```bash
   # Edit config.ini to tune parameters
   nano config.ini
   ```

2. **Run odometry estimation**
   ```bash
   python lidar_odometry.py
   ```

3. **Evaluate results**
   ```bash
   python evaluate.py
   ```

4. **View results**
   - Open `../results/evaluation_report.txt`
   - View plots: `trajectory_comparison.png`, `error_plot.png`

### Parameter Tuning

If results are poor, adjust these parameters in `config.ini`:

1. **Height filtering** (`height_min`, `height_max`)
   - Adjust based on sensor mounting height
   - Should capture wall-level features

2. **Voxel size** (`voxel_size`)
   - Increase for faster processing
   - Decrease for better accuracy

3. **ICP threshold** (`icp_threshold`)
   - Increase if ICP fails to converge
   - Decrease for tighter matching

4. **ICP iterations** (`icp_max_iter`)
   - Increase if not converging
   - Decrease for faster processing

### Advanced Configuration

The `[advanced]` section contains parameters for:

- **Outlier removal**: Filters noise from point clouds
  - `outlier_nb_neighbors`: Number of neighbors to analyze
  - `outlier_std_ratio`: Standard deviation multiplier

- **Normal estimation**: For point-to-plane ICP
  - `normal_radius`: Search radius for normal computation
  - `normal_max_nn`: Maximum neighbors for normal estimation

## Dependencies

All scripts require the packages listed in `../requirements.txt`:

```bash
# Install in virtual environment
pip install -r ../requirements.txt
```



## Notes

- All path configurations in `config.ini` are relative to the `scripts/` directory
- The scripts automatically create output directories if they don't exist
- Ground truth extraction assumes ROS2 bag format with TF transforms
- Trajectory CSV format: `timestamp, x, y, yaw` (yaw in radians)
