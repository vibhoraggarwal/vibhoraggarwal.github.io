# Indoor lidar odometry

Estimate the robot’s 2D position (x,y) and orientation (yaw) in an indoor environment using LiDAR and IMU data

## 1. Constraints

- The system relies on walls as primary features for localization and motion estimation

## 2. Requirements

>Note: I would suggest a virtual environment using

```python
python3 -m venv <path-to-virtual-env>
source <path-to-virtual-environment>/bin/activate
```

- Install python packages:
    `pip install -r requirements.txt`

## 3. Usage

- Store your `*.db` and metadata file in a relative folder `_data`

### 3.1 Run Odometry Estimation

Process the ROS bag and generate estimated trajectory:

```bash
cd scripts
python lidar_odometry.py
```

This will:

- Read LiDAR data from `_data/` directory
- Process scans using ICP-based matching
- Save estimated trajectory to `results/trajectory_estimated.csv`

### 3.2 Evaluate Results

Compare estimated trajectory against ground truth:

```bash
cd scripts
python evaluate.py
```

This will generate:

- `results/trajectory_comparison.png` - 2D trajectory plot
- `results/error_plot.png` - ATE and yaw error over time
- `results/evaluation_report.txt` - Numerical metrics

### 3.3 Quick Visualization (Optional)

Visualize any trajectory CSV:

```bash
cd scripts
python visualize.py ../results/trajectory_estimated.csv --output ../results/trajectory.png
```

## 4. Reports and Documentation

a. Summary of Results:

- **HTML** (recommended): `results/html/index.html`. It is also hosted here temporarily: [https://vibhorag.eu/temp2/](https://vibhorag.eu/temp2/)

b. Building Documentation:

```bash
cd docs/sphinx
./build_docs.sh
```

## 5. Troubleshooting

1. If processing fails:

    ```bash
    cd scripts
    python inspect_bag.py  # Check bag structure
    ```

2. To see the plots of ground truth only. Run the following command and you will see the two files: trajectory_plot.png and trajectory_data.csv in the `_data` folder.

    ```bash
    cd scripts
    python extract_and_plot.py
    ```

## 6. References

- [ICP Algorithm](https://en.wikipedia.org/wiki/Iterative_closest_point)
- [Point Cloud Library (PCL) open3d](http://www.open3d.org/)
- [Point Cloud Down Sampling methods](https://medium.com/@lathwath5/point-cloud-downsampling-methods-and-python-implementations-6f91a129ac48)
