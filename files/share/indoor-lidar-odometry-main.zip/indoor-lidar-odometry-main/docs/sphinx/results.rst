Evaluation Results
==================

This section presents the performance evaluation of the LiDAR odometry system,
including trajectory comparison and error analysis.

Trajectory Comparison
---------------------

The figure below shows the estimated trajectory compared to the ground truth path.
The estimated trajectory is generated using ICP-based scan matching with wall
feature extraction.

.. figure:: ../../results/trajectory_comparison.png
   :width: 100%
   :align: center
   :alt: Trajectory Comparison - Estimated vs Ground Truth

   **Figure 1:** 2D trajectory comparison showing the estimated path (red) versus
   ground truth (blue) in the x-y plane. The plot demonstrates the odometry system's
   ability to track the robot's motion through the indoor environment.

Error Analysis
--------------

The error plot below illustrates the temporal evolution of trajectory errors throughout
the test run.

.. figure:: ../../results/error_plot.png
   :width: 100%
   :align: center
   :alt: Error Plot - Trajectory Error Over Time

   **Figure 2:** Error plot showing the absolute trajectory error (ATE) over time.
   This visualization helps identify periods of drift and localization accuracy.

Performance Metrics
-------------------

The following metrics quantify the overall performance of the LiDAR odometry system:

.. include:: ../../results/evaluation_report.txt
   :literal:
