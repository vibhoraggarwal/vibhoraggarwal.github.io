Indoor LiDAR Odometry Report
============================

This report presents the implementation and evaluation of an indoor LiDAR odometry system
for robot localization using wall features and scan matching techniques.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   :hidden:

   problem
   algorithm
   results

Overview
--------

This project implements a 2D odometry estimation system for indoor environments using
LiDAR and IMU data. The approach leverages wall features as primary landmarks for
localization and employs ICP-based scan matching for motion estimation.

Repository and Setup Information
---------------------------------

Below you'll find detailed information about the repository structure, requirements, and usage instructions.

.. include:: ../../README.md
   :parser: myst_parser.sphinx_

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
