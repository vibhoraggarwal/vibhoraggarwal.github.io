#!/bin/bash
# Build script for Sphinx documentation

set -e

# Activate virtual environment if it exists
if [ -d "../../_venv" ]; then
    echo "Activating virtual environment..."
    source ../../_venv/bin/activate
fi

# Navigate to sphinx directory
cd "$(dirname "$0")"

echo "================================================"
echo "  Building Indoor LiDAR Odometry Documentation"
echo "================================================"
echo ""

# Clean previous builds
echo "Cleaning previous builds..."
make clean
echo ""

# Build HTML
echo "Building HTML documentation..."
make html
echo ""

# Deploy to results folder
echo "Deploying to results folder..."
make deploy
echo ""

echo "================================================"
echo "  Build Complete!"
echo "================================================"
echo ""
echo "Documentation is available at:"
echo "  - HTML: ../../results/html/index.html"
echo ""
