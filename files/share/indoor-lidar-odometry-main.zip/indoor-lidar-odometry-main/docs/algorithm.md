# Algorithm Overview

**Method:** ICP-based scan matching with wall feature extraction and IMU-aided initialization

**Steps:**
1. **Sensor Fusion Setup**:
   - Read TF static transforms (LiDAR-to-base_link)
   - Initialize IMU integration for motion prediction
2. **Preprocessing**: Filter LiDAR points by height (0.3-2.0m) to extract wall-level data
3. **Downsampling**: Voxel grid downsampling for efficiency
4. **IMU-aided Prediction**: Use IMU data for initial pose estimate between scans
5. **ICP Refinement**: Point-to-plane ICP between consecutive scans with IMU initial guess
6. **Pose Estimation**: Fuse IMU and ICP results to estimate global trajectory

**Configuration** (in `config.ini`):
- `height_min/max`: Height range for wall detection
- `voxel_size`: Downsampling resolution
- `icp_threshold`: ICP distance threshold
- `icp_max_iter`: Maximum ICP iterations
- IMU integration parameters (if applicable)

## Output Format

Trajectory CSV contains:
- `timestamp`: Time in seconds
- `x`: X position in meters
- `y`: Y position in meters
- `yaw`: Orientation in radians

## Files

- `lidar_odometry.py` - Main odometry estimation algorithm (uses config.ini)
- `lidar_odometry_core.py` - Core odometry classes and functions
- `lidar_odometry_live.py` - Real-time odometry estimation
- `evaluate.py` - Evaluation against ground truth
- `visualize.py` - Quick visualization tool
- `config.ini` - Configuration file for all parameters
- `extract_and_plot.py` - Legacy plotting script

## Performance

Expected performance on typical indoor datasets:
- Processing speed: 5-20 Hz (depending on point cloud density)
- ATE: Typically < 0.5m for short trajectories
- Yaw error: Typically < 5° for structured environments

## Tuning Tips

If results are poor:
1. Adjust `height_min/max` based on sensor mounting height
2. Increase `voxel_size` for speed, decrease for accuracy
3. Adjust `icp_threshold` based on environment scale
4. Check if scans have sufficient overlap (adjust sampling rate)


## Algorithm Details

**Approach:** ICP-based scan matching with wall feature extraction and IMU integration

**Pipeline:**

1. **Initialization**
   - Read TF static transforms from ROS bag to determine sensor mounting
   - Establish transform chain: LiDAR → base_link → odom
   - Initialize IMU data stream for motion estimation

2. **Per-Scan Processing**
   - Read LiDAR point cloud from ROS bag
   - Apply TF transform to convert points to base_link frame
   - Filter points by height (0.3m - 2.0m) to keep only wall-level points
   - Downsample with voxel grid (0.1m) for efficiency
   - Remove statistical outliers

3. **Motion Estimation**
   - **IMU Integration**: Predict motion from IMU angular velocity and linear acceleration
   - **ICP Refinement**:
     - Use IMU prediction as initial guess for ICP
     - Estimate normals for point-to-plane ICP
     - Run ICP to find refined relative transformation
     - Fuse IMU and ICP results for robust estimate
   - Update global pose estimate

4. **Output**
   - Save trajectory (timestamp, x, y, yaw)
   - Compare with ground truth for evaluation

**Key Parameters:**

- **Preprocessing:**
  - `height_min/max`: 0.3-2.0m (wall detection range)
  - `voxel_size`: 0.1m (downsampling resolution)
  - `min_points`: 100 (minimum points per scan)

- **ICP:**
  - `icp_threshold`: 0.5m (max correspondence distance)
  - `icp_max_iter`: 50 (maximum iterations)
  - `normal_radius`: 0.5m (normal estimation radius)

- **Advanced:**
  - `outlier_nb_neighbors`: 20 (for outlier removal)
  - `outlier_std_ratio`: 2.0 (standard deviation threshold)

**Sensor Fusion Benefits:**

- IMU provides good short-term motion prediction (reduces ICP search space)
- LiDAR provides accurate long-term position tracking (corrects IMU drift)
- Combined system is more robust to rapid motions and feature-poor environments

## Expected Performance

- **Processing speed:** 20-30 Hz (with IMU integration and optimized ICP)
  - Pure LiDAR mode: 5-20 Hz
  - IMU-aided mode: 20-30 Hz
- **Accuracy:** Depends on environment and sensor quality
  - ATE (position error): 0.3-0.7m for indoor trajectories
  - Yaw error: 1-5 degrees with IMU fusion
  - Best performance in structured environments with clear wall features

**Note:** IMU integration significantly improves:
- Processing speed (better ICP initialization)
- Robustness during rapid motions
- Performance in feature-poor sections of trajectory
