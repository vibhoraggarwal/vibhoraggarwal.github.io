<!-- Generated from: Robotics assignment - Lidar Odometry.pdf -->
# Problem: Indoor LiDAR Odometry

## Goal

Estimate the robot's 2D position and orientation in an indoor environment using LiDAR and IMU data. The system should rely on walls as primary features for localization and motion estimation.

## Context

Indoor environments offer strong geometric constraints through walls and fixed structures. The objective is to build an odometry method that can track the robot's motion using these consistent features.

## Provided Data

ROS bag includes:
- `/livox/amr/imu` — IMU data
- `/livox/amr/lidar` — 3D LiDAR data
- `/tf`, `/tf_static` — Dynamic and static transforms

A ground-truth transform (`odom → base_link`) is included only for evaluation — it must not be used in your algorithm.

## Evaluation

### Outputs Expected

- A 2D odometry estimate (x, y, yaw) published as `nav_msgs/Odometry` on `/odom_est`, or exported as a `.csv` file.

### Metrics

1. **Absolute Trajectory Error (ATE)** – measures how close the estimated trajectory is to the ground truth (in meters).
2. **Yaw Error** – mean absolute difference between estimated and ground-truth yaw angles (in degrees).

### Plots (for report)

1. **Trajectory Plot** – show estimated vs. ground-truth paths in 2D (x–y).
2. **Error Plot** – plot ATE or yaw error over time.

## Submission

- Trajectory file (`.bag` or `.csv`)
- Short report (1 page) including:
  - ATE and yaw error results
  - The two plots above
  - One-line description of your approach and runtime (Hz)

**Note:** Use of ground-truth data in your algorithm will result in disqualification. Only use it for evaluation.
